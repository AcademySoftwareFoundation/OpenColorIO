# Source and destination file names.
test_source = "dangerous.txt"
test_destination = "dangerous.html"

# Keyword parameters passed to publish_file.
reader_name = "standalone"
parser_name = "rst"
writer_name = "html"

# Settings
settings_overrides['file_insertion_enabled'] = 0
settings_overrides['raw_enabled'] = 0
