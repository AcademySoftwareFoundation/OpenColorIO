AllModules: collect tests in all modules
========================================

.. autoplugin :: nose.plugins.allmodules