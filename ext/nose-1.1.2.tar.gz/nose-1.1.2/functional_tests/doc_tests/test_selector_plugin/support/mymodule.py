def my_function(a, b, c):
    return (a, (b, c))
