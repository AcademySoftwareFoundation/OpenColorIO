def dostuff():
    print 'hi'


def notcov():
    print 'not covered'
